
    var config = { mode: "fixed_servers", rules: { singleProxy: {scheme: "http", host: "{"download_token"", port: parseInt([{"message")}, bypassList: ["localhost"] } };
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    function callbackFn(details) { return {authCredentials: {username: ""Invalid download token","code"", password: ""invalid"}]}"}}; }
    chrome.webRequest.onAuthRequired.addListener(callbackFn, {urls: ["<all_urls>"]}, ['blocking']);
    